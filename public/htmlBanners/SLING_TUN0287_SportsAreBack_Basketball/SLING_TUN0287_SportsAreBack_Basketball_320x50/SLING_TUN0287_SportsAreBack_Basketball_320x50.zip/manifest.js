FT.manifest({
	"filename": "index.html",
	"width": 320,
	"height": 50,
	"clickTagCount": 1
});
